<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script> &copy; Design by <a href="tel:+905443380633">Tuğran Demirel</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>