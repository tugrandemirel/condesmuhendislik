<!--footer-area start-->
<footer class="footer-area">
    <div class="footer-bg-two pt-95 pb-50" data-background="<?php echo e(asset($_siteSetting->footer_image ?? 'assets/front/img/footer/footer-bg-1a.jpg')); ?>">
        <img class="shapes__1" src="<?php echo e(asset('assets/front/img/shape/star-3a.svg')); ?>" alt="">
        <img class="shapes__2" src="<?php echo e(asset('assets/front/img/shape/line-7a.svg')); ?>" alt="">
        <div class="blur__shape"></div>
        <div class="container pt-200 pt-lg-10">
            <div class="row mb-25">
                <div class="col-xxl-3 col-lg-4 col-md-6">
                    <div class="footer__widget mb-30 px-xxl-3">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset($_siteSetting->logo)); ?>" width="217" height="62" alt="<?php echo e($_siteSetting->title); ?>"></a>
                        <p class="footer__description mt-40">  “Mühendislik'te yenilik, Condes'te evrensel standart!”</p>
                    </div>
                </div>
                <div class="col-xxl-3 col-lg-4 col-md-6">
                    <div class="footer__widget mb-30">
                        <ul class="fot-list">
                            <li>
                                <a href="<?php echo e(route('index')); ?>">Anasayfa</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('about')); ?>">Hakkımızda</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('service')); ?>">Hizmetlerimiz</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('blog')); ?>">Makalelerimiz</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('contact')); ?>">İletişim</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xxl-3 col-lg-4 col-md-6">
                    <div class="footer__widget mb-30">
                        <div class="footer__contact">

                            <?php if(!is_null($_siteSetting->phone) || !is_null($_siteSetting->phone_2)): ?>
                                <?php if($_siteSetting->phone): ?>
                                    <h4 class="phone__nimber mb-25"><a href="tel:<?php echo e($_siteSetting->phone); ?>"><?php echo e($_siteSetting->phone); ?></a></h4>
                                <?php endif; ?>
                                <?php if($_siteSetting->phone_2): ?>
                                    <h4 class="phone__nimber mb-25"><a href="tel:<?php echo e($_siteSetting->phone_2); ?>"><?php echo e($_siteSetting->phone_2); ?></a></h4>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(!is_null($_siteSetting->email)): ?>
                                    <p class="mb-0"><a href="mailto:<?php echo e($_siteSetting->email); ?>"><?php echo e($_siteSetting->email); ?></a></p>
                                <?php endif; ?>
                                <?php if(!is_null($_siteSetting->address)): ?>
                            <p class="mb-0"><?php echo e($_siteSetting->address); ?></p>
                                <?php endif; ?>
                            <p class="mb-0">P.tesi: 08.00-18.00</p>
                            <p class="mb-0">C.tesi: 08.00-18.00</p>

                        </div>
                    </div>
                </div>
                <div class="col-xxl-3 col-lg-6 col-md-6">
                    <div class="footer__widget mb-30">
                        <div class="social_media">
                           <?php $__currentLoopData = $_socialMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($_social->url); ?>" target="_blank" title="<?php echo e($_social->name); ?>">
                                <?php echo $_social->icon; ?>

                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container copyright__border">
            <div class="copyright__area pt-75">
                <div class="row align-items-center">
                    <div class="col-lg-6 text-center text-lg-start">
                        <div class="copyright__text mb-30">
                            <p>
                                <a class="fw-bold" href="tel:+905443380633">Tuğran Demirel</a>
                                © 2023 Condes Mühendislik. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>