<?php $__env->startSection('title', 'Hizmetlerimiz'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a href="#" class="dropdown-toggle arrow-none card-drop" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <!-- item-->
                            <a href="<?php echo e(route('admin.service.create')); ?>" class="dropdown-item">Ekle</a>

                        </div>
                    </div>
                    <p class="text-muted font-14 mb-3">
                        Buradan Hizmetlerim ayarlarınızı yönetebilirsiniz
                    </p>

                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Görsel</th>
                                <th>İcon</th>
                                <th>Ad</th>
                                <th>Durum</th>
                                <th>İşlem Tarihi</th>
                                <th>İşlemler</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($value->id); ?></th>
                                <td>
                                    <img src="<?php echo e(asset($value->image)); ?>" class="img-fluid" width="75" alt="<?php echo e($value->title); ?>">
                                </td>
                                <td>
                                    <?php if($value->icon): ?>
                                    <img src="<?php echo e(asset($value->icon)); ?>" class="img-fluid" width="75" alt="<?php echo e($value->title); ?>">
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($value->title); ?></td>
                                <td>
                                    <?php if($value->status == true): ?>
                                        <span class="badge bg-soft-success text-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-soft-danger text-danger">Pasif</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($value->updated_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.service.edit', ['service' => $value])); ?>" class="btn btn-primary btn-sm">Düzenle</a>
                                    <button data-url="<?php echo e(route('admin.service.destroy', ['service' => $value])); ?>" class="btn btn-danger btn-sm removeSocialMedia">SİL</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function (){
            $('.removeSocialMedia').click(function () {
                let url = $(this).data('url')
                let id = url.split('/')[5]
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: {
                        id: id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function (response){
                        if (response.success === true){
                            alert(response.message)
                            window.location.reload()
                        }
                    },
                    error: function (response){
                        alert(response.message)
                    }
                })

            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/service/index.blade.php ENDPATH**/ ?>