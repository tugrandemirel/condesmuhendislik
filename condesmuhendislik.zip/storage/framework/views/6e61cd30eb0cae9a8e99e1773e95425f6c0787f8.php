<?php $__env->startSection('title', 'Seo Ayarları'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a href="#" class="dropdown-toggle arrow-none card-drop" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <!-- item-->
                            <a href="<?php echo e(route('admin.seo.create')); ?>" class="dropdown-item">Ekle</a>

                        </div>
                    </div>
                    <p class="text-muted font-14 mb-3">
                        Buradan seo ayarlarınızı yönetebilirsiniz
                    </p>

                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>SEO Adı</th>
                                <th>Sayfa Tipi</th>
                                <th>Tarih</th>
                                <th>İşlemler</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $seos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($value->id); ?></th>
                                <td><?php echo e($value->title); ?></td>
                                <td><?php echo e($value->page_type); ?></td>
                                <td><?php echo e($value->updated_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.seo.edit', ['seo' => $value])); ?>" class="btn btn-primary btn-sm">Düzenle</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/seo/index.blade.php ENDPATH**/ ?>