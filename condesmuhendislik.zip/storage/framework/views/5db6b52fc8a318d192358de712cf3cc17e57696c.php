<?php $__env->startSection('title', ' - İletişim'); ?>
<?php $__env->startSection('meta_description', isset($seo->description)  ? $seo->description : ''  ); ?>
<?php $__env->startSection('meta_keywords', isset($seo->keywords)  ? $seo->keywords : ''  ); ?>

<?php $__env->startSection('og_title', isset($seo->title) ? $seo->title : ' İletişim'); ?>
<?php $__env->startSection('og_description', isset($seo->description) ? $seo->description : ' İletişim'  ); ?>
<?php $__env->startSection('og_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' İletişim'  ); ?>

<?php $__env->startSection('wa_title', isset($seo->title) ? $seo->title : ' İletişim'); ?>
<?php $__env->startSection('wa_description', isset($seo->description) ? $seo->description : ' İletişim'  ); ?>
<?php $__env->startSection('wa_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' İletişim'  ); ?>

<?php $__env->startSection('content'); ?>
    <!--page-title-area start-->
    <!--page-title-area start-->
    <div class="page-title-area pt-220 pb-240 pt-lg-120 pb-lg-125 pb-md-100"
         data-background="<?php echo e(asset('assets/front/img/page-title/page-title-bg-1a.jpg')); ?>">
        <img class="page-title-shape shape-one " src="<?php echo e(asset('assets/front/img/shape/line-14d.svg')); ?>" alt="shape">
        <img class="page-title-shape shape-two" src="<?php echo e(asset('assets/front/img/shape/pattern-1a.svg')); ?> " alt="shape">

        <div class="container">
            <div class="row gx-4 gx-xxl-5 align-items-center">
                <div class="col-xl-6 col-md-6">
                    <div class="page-title-wrapper text-md-start text-center">
                        <h2 class="page-title mb-10">İletişim</h2>
                        <nav aria-label="breadcrumb">
                            <ul class="breadcrumb list-none justify-content-center justify-content-md-start">
                                <li><a href="<?php echo e(route('index')); ?>">Anasayfa</a></li>
                                <li class="active" aria-current="page">İletişim</li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--page-title-area end-->

    <!--contact__section start-->
    <div class="contact__section pt-180 pb-140 pt-lg-120 pb-lg-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="contact__info__wrapper me-xxl-4 pe-xxl-5 mb-45">
                        <?php if(!is_null($_siteSetting->phone)): ?>
                        <div class="single__info__box">
                            <div class="icon">
                                <i class="bi bi-telephone"></i>
                            </div>
                            <span><a href="tel:<?php echo e($_siteSetting->phone); ?>"><?php echo e($_siteSetting->phone); ?></a></span>
                        </div>
                        <?php endif; ?>
                        <?php if(!is_null($_siteSetting->phone_2)): ?>
                        <div class="single__info__box">
                            <div class="icon">
                                <i class="bi bi-telephone"></i>
                            </div>
                            <span><a href="tel:<?php echo e($_siteSetting->phone2); ?>"><?php echo e($_siteSetting->phone2); ?></a></span>
                        </div>
                        <?php endif; ?>
                        <?php if(!is_null($_siteSetting->email)): ?>
                            <div class="single__info__box">
                                <div class="icon">
                                    <i class="bi bi-envelope"></i>
                                </div>
                                <span><a href="mailto:<?php echo e($_siteSetting->email); ?>"><?php echo e($_siteSetting->email); ?></a></span>
                            </div>
                        <?php endif; ?>
                        <?php if(!is_null($_siteSetting->address)): ?>
                        <div class="single__info__box">
                            <div class="icon">
                                <i class="bi bi-geo-alt"></i>
                            </div>
                            <span><?php echo e($_siteSetting->address); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-8">
                    <?php if(session()->has('success')): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session()->get('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?><?php echo e(session()->get('error')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endif; ?>
                    <div class="contact-form-one">
                        <h3 class="section__title__one mb-50">İletişim Formu</h3>
                        <form class="widget-form" action="<?php echo e(route('contact.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="label">Ad</label>
                                    <input type="text" name="name" placeholder="Adınız" value="<?php echo e(old('name')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red">  <?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="label">Soyad</label>
                                    <input type="text" name="surname" placeholder="Soyadınız" value="<?php echo e(old('surname')); ?>">
                                    <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red">  <?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="label">Email</label>
                                    <input type="email" name="email" placeholder="Emailiniz" value="<?php echo e(old('email')); ?>">

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red">  <?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="label">Telefon</label>
                                    <input type="text" name="phone" placeholder="Telefon Numaranız" value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red">  <?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-25">
                                    <label class="label">Mesajınız</label>
                                    <textarea name="message" placeholder="Mesajınız"><?php echo e(old('message')); ?></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red">  <?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <button class="ht_btn hover-bg border-0">Gönder</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--contact__section end-->


    <!-- cta__area start -->
    <?php echo $__env->make('front.partials.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- cta__area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/front/contact.blade.php ENDPATH**/ ?>