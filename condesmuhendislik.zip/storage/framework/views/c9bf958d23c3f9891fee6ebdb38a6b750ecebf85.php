<?php $__env->startSection('title', ' - Anasayfa'); ?>
<?php $__env->startSection('meta_description', isset($seo->description)  ? $seo->description : 'Condes Mühendislik'  ); ?>
<?php $__env->startSection('meta_keywords', isset($seo->keywords)  ? $seo->keywords : 'condes mühendislik, condes, mühendislik'  ); ?>

<?php $__env->startSection('og_title', isset($seo->title) ? $seo->title : ' Anasayfa'); ?>
<?php $__env->startSection('og_description', isset($seo->description) ? $seo->description : ' Anasayfa'  ); ?>
<?php $__env->startSection('og_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' Anasayfa'  ); ?>

<?php $__env->startSection('wa_title', isset($seo->title) ? $seo->title : ' Anasayfa'); ?>
<?php $__env->startSection('wa_description', isset($seo->description) ? $seo->description : ' Anasayfa'  ); ?>
<?php $__env->startSection('wa_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' Anasayfa'  ); ?>

<?php $__env->startSection('content'); ?>
    <!-- theme__main__banner start -->
    <section class="theme__main__banner black-bg pt-215 pb-205 pb-lg-100">

        <?php if(session()->has('success')): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?><?php echo e(session()->get('success')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'danger']); ?><?php echo e(session()->get('error')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
        <div class="shapes__blur"></div>
        <?php if(!is_null($_siteSetting->header_image)): ?>
            <img class="shapes shapes__1" src="<?php echo e(asset($_siteSetting->header_image)); ?>"
                 alt="<?php echo e($_siteSetting->title); ?>">
        <?php endif; ?>
        <img class="shapes shapes__2" src="<?php echo e(asset('assets/front/img/shape/hero-line-1.svg')); ?>" alt="Shape Two">
        <img class="shapes shapes__3" src="<?php echo e(asset('assets/front/img/shape/star-1.svg')); ?>" alt="Shape Three">

        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-9 col-lg-12">
                    <div class="theme__content text-xl-start text-center mb-5 mb-lg-0">
                        <h4 class="sub__title mb-25">VERİMLİLİĞİ OPTİMİZE EDİN</h4>
                        <h2 class="main__title mb-45">Fabrika & Endüstriler için En İyi Çözümler
                        </h2>
                        <a href="<?php echo e(route('contact')); ?>" class="ht_btn"><span>Şimdi Keşfet <img
                                    src="<?php echo e(asset('assets/front/img/icon/arrow1.svg')); ?>" alt=""></span></a>
                    </div>
                </div>
                <div class="col-lg-6 d-none">
                    <div class="hero__img">
                        <img src="<?php echo e(asset('assets/front/img/hero/hero-main-1a.jpg')); ?>" alt="hero__img">
                    </div>
                </div>
            </div>
        </div>
        <?php if($sliders->count() > 0): ?>
            <div class="swiper hero__slider">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <img src="<?php echo e($slider->image); ?>" alt="<?php echo e($_siteSetting->title); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="swiper-pagination"></div>

                <div class="swiper-button-prev"><img src="<?php echo e(asset('assets/front/img/icon/chevron-arrow-left.svg')); ?>"
                                                     alt="Arrow"></div>
                <div class="swiper-button-next"><img src="<?php echo e(asset('assets/front/img/icon/chevron-arrow-right.svg')); ?>"
                                                     alt="Arrow">
                </div>
            </div>
        <?php endif; ?>
    </section>
    <!-- theme__maina__banner end -->

    <!-- about__area start -->
    <section class="about__area">
        <div class="grey-bg about__section__wrapper pt-180 pb-70 pt-lg-120 pb-lg-30">
            <div data-text="About" class="big-style-text">HAKKIMIZDA</div>
            <img class="about__shape__1" src="<?php echo e(asset('assets/front/img/shape/about-line-2a.svg')); ?>"
                 alt="About Shape">
            <img class="about__shape__2" src="<?php echo e(asset('assets/front/img/shape/about-line-3a.svg')); ?>"
                 alt="About Shape">
            <div class="container">
                <div class="row align-items-center mb-20">
                    <div class="col-lg-9 pe-lg-0">
                        <div class="section__title text-lg-start text-center mb-30">
                            <h4 class="sub__title__one mb-0">HAKKIMIZDA</h4>
                            <div class="snake-line mb-15">
                                <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                            </div>
                            <h2 class="section__title__one">Endüstrileri yenilikçi çözümlerle güçlendirerek, verimliliği
                                ve üretkenliği artırmak için fabrika operasyonlarında devrim yaratıyoruz.</h2>
                        </div>
                    </div>
                    <div class="col-lg-3 d-flex justify-content-center justify-content-lg-end">
                        <div class="about__circular__box mb-30">
                            <img src="<?php echo e(asset('assets/front/img/about/circular-text.png')); ?>" alt="Circular Text">
                            <span>A+</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="single__box mb-30">
                            <div class="icon mb-35">
                                <img class="front-icon" src="<?php echo e(asset('assets/front/img/icon/icon-1a.svg')); ?>"
                                     alt="Icon">
                                <img class="back-icon" src="<?php echo e(asset('assets/front/img/icon/icon-1w.svg')); ?>"
                                     alt="Icon">
                            </div>
                            <h3 class="single__box__title"><a href="#">Tam Otomasyon</a></h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single__box mb-30">
                            <div class="icon mb-35">
                                <img class="front-icon" src="<?php echo e(asset('assets/front/img/icon/icon-2a.svg')); ?>"
                                     alt="Icon">
                                <img class="back-icon" src="<?php echo e(asset('assets/front/img/icon/icon-2w.svg')); ?>"
                                     alt="Icon">
                            </div>
                            <h3 class="single__box__title"><a href="#">Ölçeklenebilir Çözümler</a></h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single__box mb-30">
                            <div class="icon mb-35">
                                <img class="front-icon" src="<?php echo e(asset('assets/front/img/icon/icon-3a.svg')); ?>"
                                     alt="Icon">
                                <img class="back-icon" src="<?php echo e(asset('assets/front/img/icon/icon-3w.svg')); ?>"
                                     alt="Icon">
                            </div>
                            <h3 class="single__box__title"><a href="#">Enerji Verimliliği</a></h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single__box mb-30">
                            <div class="icon mb-35">
                                <img class="front-icon" src="<?php echo e(asset('assets/front/img/icon/icon-4a.svg')); ?>"
                                     alt="Icon">
                                <img class="back-icon" src="<?php echo e(asset('assets/front/img/icon/icon-4w.svg')); ?>"
                                     alt="Icon">
                            </div>
                            <h3 class="single__box__title"><a href="#">Güvenli & Emniyetli</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about__area end -->
    <?php if($services->count() > 0): ?>
        <!-- services__area start -->
        <section class="services__area pt-180 pb-45 pt-lg-60 pb-lg-40">
            <div class="big-style-text">HİZMETLERİMİZ</div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section__title text-center mb-50">
                            <h4 class="sub__title__one mb-0">HİZMETLERİMİZ</h4>
                            <div class="snake-line mb-15">
                                <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                            </div>
                            <h2 class="section__title__one">Hizmetlerimiz İle <span>En İyi</span> Dönüşüme Uğrayın
                            </h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper services__slide__one pb-60">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="single__services__box mb-60">
                                            <div class="services__thumb">
                                                <img class="w-100" src="<?php echo e(asset($service->image)); ?>"
                                                     width="410" height="370" alt="Service">
                                            </div>
                                            <div class="services__content">
                                                <h4 class="single__service__title"><a
                                                        href="<?php echo e(route('service.detail', ['slug' => $service->slug])); ?>"><?php echo e($service->title); ?></a>
                                                </h4>
                                                <a href="<?php echo e(route('service.detail', ['slug' => $service->slug])); ?>"><img
                                                        src="<?php echo e(asset('assets/front/img/icon/long-arrow.svg')); ?>"
                                                        alt="Arrow"></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- If we need pagination -->
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- services__area end -->
    <?php endif; ?>
    <!-- chose__us__area start -->
    <section class="chose__us__area pt-120 pt-lg-60 pb-85 pb-lg-30">
        <div class="chose__section__wrapper">
            <div class="big-style-text">NEDEN</div>
            <div class="chose__video__content" data-background="<?php echo e(asset($_siteSetting->home_first_image)); ?>">
                <?php if(!is_null($_siteSetting->home_first_url)): ?>
                    <div class="video__wrapper">
                        <a class="popup-video mb-30" href="<?php echo e(asset($_siteSetting->home_first_url)); ?>"><i
                                class="bi bi-play-fill"></i></a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6"></div>
                    <div class="col-lg-6">
                        <div class="chose__text__wrapper ps-xl-5 ms-xl-4 mb-30 pt-50">
                            <h4 class="sub__title__one mb-0">NEDEN BİZİMLE ÇALIŞMALISINIZ</h4>
                            <div class="snake-line mb-15">
                                <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                            </div>
                            <h2 class="section__title__one mb-30">Deneyim, inovasyon ve müşteri memnuniyetiyle dolu bir
                                ekibiz
                            </h2>
                            <ul class="text-list list-none">
                                <li>Sektöre Özel Çözümlerde Uzmanlık</li>
                                <li>En Son Teknolojiler ve Yenilikler</li>
                                <li>Mevzuata Uygunluk ve Risk Azaltma</li>
                                <li>Güvenilir, Profesyonel ve Zamanında Yürütme</li>
                                <li>Ölçeklenebilirlik ve Esneklik</li>
                            </ul>
                            <div class="mt-60">
                                <a href="<?php echo e(route('contact')); ?>" class="ht_btn hover-bg">
                                    <span>DAHA FAZLASI İÇİN
                                        <img src="<?php echo e(asset('assets/front/img/icon/arrow1.svg')); ?>" alt="">
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- chose__us__area end -->

    <!-- counter__area star -->
    <section class="counter__area">
        <div class="grey-bg counter__section__wrapper">
            <img class="shapes__1 d-none d-xl-inline-block" src="<?php echo e(asset('assets/front/img/shape/line-9a.svg')); ?>"
                 alt="Shape">
            <img class="shapes__2 d-none d-xl-inline-block" src="<?php echo e(asset('assets/front/img/shape/line-10a.svg')); ?>"
                 alt="Shape">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="counter__box mb-30">
                            <h3 class="counter__number"><span class="counter">5</span>Yıl</h3>
                            <p>Deneyim<br/>Süremiz</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="counter__box ps-xl-5 mb-30">
                            <h3 class="counter__number"><span class="counter"><?php echo e($services->count()); ?></span></h3>
                            <p>Toplam<br/>Hizmetimiz</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="counter__box ps-xl-5 mb-30">
                            <h3 class="counter__number"><span class="counter">2</span>.5+k</h3>
                            <p>Mutlu<br/>
                                Müşterilerimiz</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- counter__area end -->

    <!-- video__area start -->
    <section class="video__area">
        <div class="video__section__wrapper pb-80 pb-lg-60">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="full__video__bg" data-background="<?php echo e(asset($_siteSetting->home_second_image)); ?>">
                            <?php if(!is_null($_siteSetting->home_second_url)): ?>
                                <div class="video__wrapper">
                                    <img class="video__text"
                                         src="<?php echo e(asset('assets/front/img/video/video-text-circular.svg')); ?>"
                                         alt="Circular">
                                    <a class="popup-video" href="<?php echo e($_siteSetting->home_second_url); ?>"><i
                                            class="bi bi-play-fill"></i></a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- video__area end -->

    <!-- working__process__area start -->
    <section class="working__process__area pt-90 pb-130 pt-lg-10 pb-lg-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section__title text-center mb-70 px-3">
                        <h4 class="sub__title__one mb-0">ÇALIŞMA SÜRECİMİZ</h4>
                        <div class="snake-line mb-15">
                            <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                        </div>
                        <h2 class="section__title__one">Bizim Uzmanlığımızı Seçmenin Faydaları</h2>
                    </div>
                </div>
            </div>
            <ul class="row working__process__list1">
                <li class="col-xxl-3 col-md-6">
                    <div class="working__step step-1 mb-30">
                        <span class="step mb-20">Adım 01</span>
                        <h3 class="single__box__title mb-15">Araştırma</h3>
                        <p>Gereksinimleri, kısıtlamaları anlamak için veri ve içgörüler topluyoruz</p>
                    </div>
                </li>
                <li class="col-xxl-3 col-md-6">
                    <div class="working__step step-2 mb-30">
                        <span class="step mb-20">Adım 02</span>
                        <h3 class="single__box__title mb-15">Planlama</h3>
                        <p>Her ayrıntıyı gözden geçiriyoruz. Uzman ekibimiz ile yapılması gerekenlerin yol haritasını
                            çiziyoruz</p>
                    </div>
                </li>
                <li class="col-xxl-3 col-md-6">
                    <div class="working__step step-3 mb-30">
                        <span class="step mb-20">Adım 03</span>
                        <h3 class="single__box__title mb-15">Uygulama</h3>
                        <p>Konforunuzu artırmak için enerji verimliliğini yükseltiyor, sıcaklığı sizinle uyumlu hale
                            getiriyoruz</p>
                    </div>
                </li>
                <li class="col-xxl-3 col-md-6">
                    <div class="working__step step-4 mb-30">
                        <span class="step mb-20">Adım 04</span>
                        <h3 class="single__box__title mb-15">Sonuç</h3>
                        <p>Sera gibi serin bir çevre sağlıyor, işlerinizi sıcak günlerde bile rahatlıkla yürütmenize
                            yardımcı oluyoruz</p>
                    </div>
                </li>
            </ul>
        </div>
    </section>
    <!-- working__process__area end -->

    <!-- faq__area start -->
    <section class="faq__area">
        <div class="grey-bg faq__section__wrapper pt-140 pb-90 pt-lg-60 pb-lg-30">
            <div class="big-style-text">SSS</div>
            <img class="shapes__1" src="<?php echo e(asset('assets/front/img/shape/faq-line-4a.svg')); ?>" alt="Shape">
            <img class="shapes__2" src="<?php echo e(asset('assets/front/img/shape/faq-line-5a.svg')); ?>" alt="Shape">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="faq__que__list mb-30 pe-xl-5 me-xl-4">
                            <div class="section__title mb-50">
                                <h4 class="sub__title__one mb-0">SSS</h4>
                                <div class="snake-line mb-15">
                                    <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                                </div>
                                <h2 class="section__title__one">Sıkca Sorulan Sorular</h2>
                            </div>
                            <div class="accordion accordion-one mb-60" id="accordionExample">
                                <div class="accordion-item mb-20">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapseOne" aria-expanded="true"
                                                aria-controls="collapseOne">
                                            Periyodik kontrol nedir?
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show"
                                         aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>
                                                İş ekipmanlarının, iş Ekipmanlarının Kullanımında Sağlık ve Güvenlik
                                                Şartları Yönetmeliğinde öngörülen aralıklarda ve belirtilen yöntemlere
                                                uygun olarak, yetkili kişilerce yapılın muayene, deney ve test
                                                faaliyetlerine denir.
                                            </p>

                                            <p>
                                                Periyodik kontrolleri yapmaya yetkili kişi: İş Ekipmanlarının Kullanımında
                                                Sağlık ve Güvenlik Şartları Yönetmeliğinde belirtilen iş ekipmanlarının
                                                teknik özelliklerinin gerektirdiği ve EK-Ill'te yer alan istisnalar
                                                saklı kalmak kaydıyla EKIPNET'e kayıtlı ilgili branşlardan mühendis,
                                                teknik öğretmen, tekniker ve yüksek teknikerleri kapsar.
                                            </p>
                                            <p>
                                                İşci sağlığı ve iş güvenliği tüzüğü periodik kontrol konusundaki
                                                yeterliliği "ehliyeti hükümet veya mahalli idarelerce kabul edilen teknik
                                                elemanlar tarafından yapılacak" şeklinde ifade etmiştir. Uygulamada
                                                bakanlık müfettişleri yaptığı denetimlerde yeterli teknik eleman olarak
                                                makina mühendislerini kabul etmektedir.
                                                <small>(Yürürlükten Kaldırıldı)</small>
                                            </p>

                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-20">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                aria-expanded="false" aria-controls="collapseTwo">
                                            Neden periyodik kontrol yaptırmalıyız?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse"
                                         aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>
                                                Periodik kontrol bakim, onarım ve makinalarin revizyon süreclerinin bir
                                                parçasıdır. Kontrollerde belirtilen uygunsuzlukların bakım faaliyetiyle
                                                giderilmesi
                                                gerekmektedir.
                                            </p>
                                            <p>
                                                Periodik kontrol eğitim sürecinin bir parçasıdır. Firmada çalışan
                                                operatörlerin kullandıkları makinalar için yetkinlikleri
                                                değerlendirilir.

                                            </p>
                                            <p>Periyodik kontrol firma içi risk yönetiminin bir parçasıdır ve işletme
                                                körlüğünü
                                                azaltır. Dışardan gelen bağımsız bir denetçi is proseslerinize ve
                                                kullanılan makinalara farklı bir gözle bakarak muayene eder.
                                            </p>
                                            <p>
                                                Denetim ve kontrol bir eğitim sürecidir. Periyodik kontrolere ve ilgili
                                                idarelerin yapacağı denetimlere bu açıdan bakılmalı, bu süreçlerde
                                                harcanan zaman ve uygulamaların yararları işletmelere aktarılmalıdır.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-20">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                aria-expanded="false" aria-controls="collapseThree">
                                            Periyodik kontrolleri kim tarafından yapılıyor?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse"
                                         aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Çalışma ve Sosyal Güvenlik Bakanlığının görevlendirmiş olduğu yetkili
                                                makine mühendisleri tarafından yapılmaktadır.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-20">
                                    <h2 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                aria-expanded="false" aria-controls="collapseFour">
                                            Periyodik kontrol ne kadar süre ile yapılır?
                                        </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse"
                                         aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>İş ekipmanının standartında belirtilmedi ise, üretici firmanın
                                                belirlediği aralıklarla yapılır, üretici firmada belirtmedi ise işletme
                                                risk değerlendirmesi yaparak belirtir, işletme de belirtmedi ise azami 1
                                                yıl süreyle periyodik kontrolller yapılır.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-20">
                                    <h2 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseFive"
                                                aria-expanded="false" aria-controls="collapseFive">
                                            İş Sağlığı ve Güvenliği Neden Önemli?
                                        </button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse"
                                         aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>
                                                Her insan sağlıklı ve güvenli bir ortamda çalışmak ister. İş sağlığı ve
                                                güvenliği, çalışanların işe başladıkları andan itibaren işyerinde
                                                karşılaşabilecekleri her türlü tehlikeyi ortadan kaldırmak, azaltmak ve
                                                önlemek için alınan tedbirlerin tümüdür. İş sağlığı ve güvenliği
                                                çalışanların sağlığını ve güvenliğini korumak için alınan önlemler
                                                bütünüdür.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('contact')); ?>" class="ht_btn hover-bg"><span>Soru Sor <img
                                        src="<?php echo e(asset('assets/front/img/icon/arrow1.svg')); ?>" alt=""></span></a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="faq__img__wrapper mb-30">
                            <div class="counter__wrapper">
                                <h5>Deneyim</h5>
                                <h3>5 <span>+</span></h3>
                                <h5>Yıldan Fazla</h5>
                            </div>
                            <?php if(!is_null($_siteSetting->home_faq_main)): ?>
                                <img class="faq__img__main w-100" src="<?php echo e(asset($_siteSetting->home_faq_main)); ?>"
                                     alt="<?php echo e($_siteSetting->title); ?>">
                            <?php endif; ?>
                            <?php if(!is_null($_siteSetting->home_faq_up)): ?>
                                <img class="faq__thumb1 d-none d-lg-inline-block"
                                     src="<?php echo e(asset($_siteSetting->home_faq_up)); ?>" alt="<?php echo e($_siteSetting->title); ?>">
                            <?php endif; ?>
                            <?php if(!is_null($_siteSetting->home_faq_down)): ?>
                                <img class="faq__thumb2 d-none d-lg-inline-block"
                                     src="<?php echo e(asset($_siteSetting->home_faq_down)); ?>" alt="<?php echo e($_siteSetting->title); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- faq__area end -->
    <?php if($blogs->count() > 0): ?>
        <!-- blog__area start -->
        <section class="blog__area pt-180 pt-md-60 pb-170 pb-lg-60">
            <div class="big-style-text">MAKALELERİMİZ</div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="section__title text-center mb-50">
                            <h4 class="sub__title__one mb-0">Son Yazılarımız</h4>
                            <div class="snake-line mb-15">
                                <img src="<?php echo e(asset('assets/front/img/shape/snake-line-1a.svg')); ?>" alt="line">
                            </div>
                            <h2 class="section__title__one">MAKALELER</h2>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center justify-content-center">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog__one mb-30">
                                <div class="blog__thumb mb-25">
                                    <a href="<?php echo e(route('blog.detail', ['slug' => $blog->slug])); ?>">
                                        <img class="w-100" src="<?php echo e(asset($blog->image)); ?>" width="410" height="320"
                                             alt="Blog"></a>
                                </div>
                                <h3 class="blog__title"><a
                                        href="<?php echo e(route('blog.detail', ['slug' => $blog->slug])); ?>"><?php echo e($blog->title); ?></a>
                                </h3>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="more__btn__box text-center mt-30">
                    <a href="<?php echo e(route('blog')); ?>" class="ht_btn hover-bg"><span>Daha Fazlası <img
                                src="<?php echo e(asset('assets/front/img/icon/arrow1.svg')); ?>" alt=""></span></a>
                </div>
            </div>
        </section>
        <!-- blog__area end -->
    <?php endif; ?>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/front/index.blade.php ENDPATH**/ ?>