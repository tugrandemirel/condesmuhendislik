<div class="alert alert-<?php echo e($type); ?> <?php echo e($attributes->merge(['class' => 'alert alert-'.$type])); ?>" role="alert">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/components/alert.blade.php ENDPATH**/ ?>