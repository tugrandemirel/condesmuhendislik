<?php $__env->startSection('title', 'Mesajlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <p class="text-muted font-14 mb-3">
                        Buradan size iletilen mesajları görebilirsiniz. En son iletilen mesaj en üstte görünmektedir.
                    </p>

                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Ad-Soyad</th>
                                <th>Mail</th>
                                <th>İşlem Tarihi</th>
                                <th>İşlemler</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($value->id); ?></th>
                                <td><?php echo e($value->name); ?> <?php echo e($value->surname); ?> </td>
                                <td><?php echo e($value->email); ?></td>
                                <td><?php echo e($value->updated_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.contact.show', ['contact' => $value])); ?>" class="btn btn-primary btn-sm">Gör</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>