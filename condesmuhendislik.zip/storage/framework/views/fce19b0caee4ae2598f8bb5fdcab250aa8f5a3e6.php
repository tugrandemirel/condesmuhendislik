<?php $__env->startSection('title', 'Mesaj Ayrıntıları'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Mesaj Ayrıntıları</h4>
                    <div class="row mt-5">
                        <div class="col-lg-4">
                            <div class="mb-3">
                                <label class="form-label">Ad-Soyad:</label>

                                <a href="#"><?php echo e($contact->name.' '.$contact->surname); ?></a>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="mb-3">
                                <label class="form-label">Telefon:</label>
                                <a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="mb-3">
                                <label class="form-label">Email:</label>
                                <a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <p>
                                    <?php echo e($contact->message); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>