<?php $__env->startSection('title', ' - Makalelerimiz'); ?>
<?php $__env->startSection('meta_description', isset($seo->description)  ? $seo->description : ''  ); ?>
<?php $__env->startSection('meta_keywords', isset($seo->keywords)  ? $seo->keywords : ''  ); ?>

<?php $__env->startSection('og_title', isset($seo->title) ? $seo->title : ' Makalelerimiz'); ?>
<?php $__env->startSection('og_description', isset($seo->description) ? $seo->description : ' Makalelerimiz'  ); ?>
<?php $__env->startSection('og_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' Makalelerimiz'  ); ?>

<?php $__env->startSection('wa_title', isset($seo->title) ? $seo->title : ' Makalelerimiz'); ?>
<?php $__env->startSection('wa_description', isset($seo->description) ? $seo->description : ' Makalelerimiz'  ); ?>
<?php $__env->startSection('wa_image', isset($_siteSetting->logo) ? asset($_siteSetting->logo) : ' Makalelerimiz'  ); ?>

<?php $__env->startSection('content'); ?>
    <!--page-title-area start-->
    <div class="page-title-area pt-220 pb-240 pt-lg-120 pb-lg-125 pb-md-100"
         data-background="<?php echo e(asset($_siteSetting->blog_image)); ?>">
        <img class="page-title-shape shape-one " src="<?php echo e(asset('assets/front/img/shape/line-14d.svg')); ?>" alt="shape">
        <img class="page-title-shape shape-two" src="<?php echo e(asset('assets/front/img/shape/pattern-1a.svg')); ?> " alt="shape">

        <div class="container">
            <div class="row gx-4 gx-xxl-5 align-items-center">
                <div class="col-xl-6 col-md-6">
                    <div class="page-title-wrapper text-md-start text-center">
                        <h2 class="page-title mb-10">Blog</h2>
                        <nav aria-label="breadcrumb">
                            <ul class="breadcrumb list-none justify-content-center justify-content-md-start">
                                <li><a href="<?php echo e(route('index')); ?>">Anasayfa</a></li>
                                <li class="active" aria-current="page">Makalalelerimiz</li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--page-title-area end-->

    <!-- blog__area start -->
    <section class="blog__area pt-180 pt-lg-120 pb-170 pb-lg-120">
        <div class="container">
            <div class="section__title text-center mb-50">
                <h2 class="section__title__one">Son Makalelerimiz</h2>
            </div>
            <div class="row align-items-center justify-content-center">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="blog__one mb-30">
                            <div class="blog__thumb">
                                <a href="<?php echo e(route('blog.detail', ['slug' => $blog->slug])); ?>"><img class="w-100" src="<?php echo e(asset($blog->image)); ?>" alt="<?php echo e($blog->title); ?>"></a>
                            </div>
                            <div class="blog__content__one">
                                <h3 class="blog__title__three">
                                    <a href="<?php echo e(route('blog.detail', ['slug' => $blog->slug])); ?>"><?php echo e($blog->title); ?></a>
                                </h3>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="more__btn__box text-center mt-30">
                <a href="<?php echo e(route('contact')); ?>" class="ht_btn hover-bg"><span>Daha Fazlası İçin <img
                            src="<?php echo e(asset('assets/front/img/icon/arrow1.svg')); ?>" alt=""></span></a>
            </div>
        </div>
    </section>
    <!-- blog__area end -->

    <!-- cta__area start -->
    <?php echo $__env->make('front.partials.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- cta__area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/front/blog.blade.php ENDPATH**/ ?>