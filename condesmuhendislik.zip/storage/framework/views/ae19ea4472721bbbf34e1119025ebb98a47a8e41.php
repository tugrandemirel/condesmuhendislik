<?php $__env->startSection('title', isset($slider) ? 'Site Ayarı Güncelle' : 'Site Ayarı Ekle'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Site Ayarları</h4>
                    <p class="sub-header">
                        Buradan site ayarlarınızı <?php echo e(isset($slider) ? 'güncelleyebilirsiniz' : 'kaydedebilirsiniz'); ?>

                    </p>
                    <form action="<?php echo e(isset($slider) ? route('admin.slider.update',['slider' => $slider]) : route('admin.slider.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($slider)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">Slider Resim</label>
                                    <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image" value="<?php echo e(isset($slider) ? $slider->image : old('image')); ?>">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php if(isset($slider->image)): ?>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label class="form-label">
                                            <img src="<?php echo e(asset($slider->image)); ?>" alt="" class="img-fluid">
                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6">
                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                    <?php echo e(isset($slider) ? 'Güncelle' : 'Kaydet'); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $('#addPhone').click(function () {
                var html = '' +
                    '<div class="col-md-9">' +
                    '<div class="mb-3">' +
                    '<label class="form-label">Site Telefon Numarası</label>' +
                    '<div class="input-group">' +
                    '<input type="text" class="form-control" name="phone[]" value=""> ' +
                    '<button class="btn input-group-text btn-danger waves-effect waves-danger removeButton" type="button">x</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>'
                $('.phones').append(html);
            });
            $(document).on('click', '.removeButton', function () {
                console.log('test')
                $(this).closest('.col-md-9').remove();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\condesmuhendislik\resources\views/admin/slider/create-edit.blade.php ENDPATH**/ ?>