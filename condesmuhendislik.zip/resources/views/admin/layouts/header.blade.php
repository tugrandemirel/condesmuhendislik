
<head>

    <meta charset="utf-8" />
    <title>@yield('title') - CondesMühendislik</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="CondesMuhendislik" name="Tuğran Demirel" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App css -->

    <link href="{{ asset('assets/admin/css/app.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />

    <!-- icons -->
    <link href="{{ asset('assets/admin/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    @yield('css')
</head>
